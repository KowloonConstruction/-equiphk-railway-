import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, Loader2, CheckCircle, Languages, RefreshCw } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function AdminDescriptionRegeneration() {
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState<any>(null);

  // Translation state
  const [isTranslating, setIsTranslating] = useState(false);
  const [translateResult, setTranslateResult] = useState<any>(null);
  const [translateTarget, setTranslateTarget] = useState<"all" | "equipment" | "consumables" | "bundles">("all");
  const [overwrite, setOverwrite] = useState(false);
  const [batchSize, setBatchSize] = useState(5);
  const [offset, setOffset] = useState(0);

  const regenerateMutation = trpc.admin.regenerateDescriptions.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setIsRunning(false);
      if (data.success) {
        toast.success(`Successfully updated ${data.updated} descriptions!`);
      } else {
        toast.error(data.message);
      }
    },
    onError: (error) => {
      setIsRunning(false);
      toast.error(`Error: ${error.message}`);
    },
  });

  const translateMutation = trpc.admin.translateAll.useMutation({
    onSuccess: (data) => {
      setTranslateResult(data);
      setIsTranslating(false);
      if (data.succeeded > 0) {
        toast.success(`Translated ${data.succeeded} item(s) to Chinese!`);
        // Auto-advance offset for next batch
        if (data.batchCount === batchSize && data.totalToFill > offset + batchSize) {
          setOffset((prev) => prev + batchSize);
        }
      } else {
        toast.info("No items needed translation in this batch.");
      }
    },
    onError: (error) => {
      setIsTranslating(false);
      toast.error(`Translation error: ${error.message}`);
    },
  });

  const handleRegenerate = () => {
    if (window.confirm("This will regenerate descriptions for all equipment items. Continue?")) {
      setIsRunning(true);
      setResult(null);
      regenerateMutation.mutate();
    }
  };

  const handleTranslateAll = () => {
    setIsTranslating(true);
    setTranslateResult(null);
    translateMutation.mutate({
      target: translateTarget,
      overwrite,
      batchSize,
      offset,
    });
  };

  const handleTranslateNext = () => {
    setIsTranslating(true);
    translateMutation.mutate({
      target: translateTarget,
      overwrite,
      batchSize,
      offset,
    });
  };

  return (
    <div className="min-h-screen bg-navy-deep pt-24 pb-16">
      <div className="container max-w-2xl space-y-8">

        {/* ── Section 1: Translate to Chinese ── */}
        <div>
          <h1 className="text-4xl font-bold text-white font-[Oswald] mb-2 flex items-center gap-3">
            <Languages className="w-8 h-8 text-orange" />
            Translate to Chinese (繁體中文)
          </h1>
          <p className="text-cream/70 mb-6">
            Auto-generate Traditional Chinese (zh-HK) names and descriptions for all equipment, consumables, and bundles using AI. Only items without existing Chinese text are translated by default.
          </p>

          <Card className="bg-navy-light border-orange/20 p-6 mb-4">
            <div className="space-y-5">
              {/* Options */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs text-cream/60 uppercase tracking-wider">Target</Label>
                  <Select value={translateTarget} onValueChange={(v: any) => { setTranslateTarget(v); setOffset(0); setTranslateResult(null); }}>
                    <SelectTrigger className="bg-navy-deep border-white/10 text-cream">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All (Equipment + Consumables + Bundles)</SelectItem>
                      <SelectItem value="equipment">Equipment Only</SelectItem>
                      <SelectItem value="consumables">Consumables Only</SelectItem>
                      <SelectItem value="bundles">Bundles Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs text-cream/60 uppercase tracking-wider">Batch Size (per run)</Label>
                  <Select value={batchSize.toString()} onValueChange={(v) => setBatchSize(parseInt(v))}>
                    <SelectTrigger className="bg-navy-deep border-white/10 text-cream">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 items</SelectItem>
                      <SelectItem value="5">5 items</SelectItem>
                      <SelectItem value="10">10 items</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Switch checked={overwrite} onCheckedChange={(v) => { setOverwrite(v); setOffset(0); setTranslateResult(null); }} />
                <div>
                  <Label className="text-sm text-cream">Overwrite existing translations</Label>
                  <p className="text-xs text-cream/40">Off = only translate items missing Chinese text (recommended)</p>
                </div>
              </div>

              {/* Status */}
              {isTranslating && (
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 flex gap-3">
                  <Loader2 className="w-5 h-5 text-blue-400 animate-spin flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-blue-300">Translating...</h3>
                    <p className="text-blue-200/80 text-sm">
                      Sending items to AI for Traditional Chinese translation. This may take 10–30 seconds per batch.
                    </p>
                  </div>
                </div>
              )}

              {/* Results */}
              {translateResult && (
                <div className="rounded-lg p-4 border bg-green-500/10 border-green-500/30 space-y-3">
                  <div className="flex gap-3">
                    <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h3 className="font-bold text-green-300 mb-1">Batch Complete</h3>
                      <div className="text-sm space-y-0.5 text-cream/70">
                        <p><span className="text-green-300 font-semibold">{translateResult.succeeded}</span> translated successfully</p>
                        {translateResult.failed > 0 && <p><span className="text-red-300 font-semibold">{translateResult.failed}</span> failed</p>}
                        <p>Items still needing translation: <span className="text-orange font-semibold">{Math.max(0, translateResult.totalToFill - offset - translateResult.batchCount)}</span></p>
                      </div>
                    </div>
                  </div>

                  {/* Sample results */}
                  {translateResult.results?.length > 0 && (
                    <div className="bg-navy-deep rounded-lg p-3 border border-white/10 max-h-48 overflow-y-auto space-y-2">
                      {translateResult.results.map((r: any) => (
                        <div key={`${r.table}-${r.id}`} className={`text-xs pb-2 border-b border-white/5 last:border-0 ${r.status === "error" ? "text-red-300" : "text-cream/70"}`}>
                          <span className="font-semibold text-cream">{r.name}</span>
                          {r.nameZh && <span className="ml-2 text-orange">→ {r.nameZh}</span>}
                          {r.error && <span className="ml-2 text-red-400">Error: {r.error}</span>}
                          <span className="ml-2 text-cream/30 capitalize">[{r.table}]</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleTranslateAll}
                  disabled={isTranslating}
                  className="flex-1 bg-orange hover:bg-orange-dark text-white font-[Oswald] uppercase tracking-wider h-11 gap-2"
                >
                  {isTranslating ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Translating...</>
                  ) : (
                    <><Languages className="w-4 h-4" /> Translate Batch (offset: {offset})</>
                  )}
                </Button>
                {translateResult && translateResult.totalToFill > offset + batchSize && (
                  <Button
                    onClick={handleTranslateNext}
                    disabled={isTranslating}
                    variant="outline"
                    className="border-orange/40 text-orange hover:bg-orange/10 font-[Oswald] uppercase tracking-wider h-11 gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Next Batch
                  </Button>
                )}
                {offset > 0 && (
                  <Button
                    onClick={() => { setOffset(0); setTranslateResult(null); }}
                    variant="outline"
                    size="sm"
                    className="border-white/20 text-cream/50 hover:text-cream h-11"
                  >
                    Reset
                  </Button>
                )}
              </div>
            </div>
          </Card>

          <Card className="bg-navy-light border-orange/20 p-5">
            <h3 className="font-bold text-orange mb-3 text-sm">How translation works:</h3>
            <ul className="space-y-1.5 text-cream/70 text-sm">
              <li>✓ AI translates each item name and description to Traditional Chinese (zh-HK)</li>
              <li>✓ New items added via admin forms are auto-translated immediately on save</li>
              <li>✓ Use this tool to backfill existing inventory in batches</li>
              <li>✓ Chinese text appears on the site when users switch to 中文 mode</li>
              <li>✓ You can manually edit Chinese fields in any item's edit form</li>
            </ul>
          </Card>
        </div>

        {/* ── Section 2: Regenerate English Descriptions ── */}
        <div>
          <h2 className="text-3xl font-bold text-white font-[Oswald] mb-2">
            Regenerate English Descriptions
          </h2>
          <p className="text-cream/70 mb-6">
            Regenerate unique, AI-powered descriptions for all equipment items with mixed tone (technical for B2B, casual for DIY).
          </p>

          <Card className="bg-navy-light border-orange/20 p-8 mb-8">
            <div className="space-y-6">
              {/* Warning */}
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 flex gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-bold text-yellow-300 mb-1">Important</h3>
                  <p className="text-yellow-200/80 text-sm">
                    This process will replace all current descriptions with AI-generated unique ones. This may take 1-2 minutes depending on the number of items.
                  </p>
                </div>
              </div>

              {/* Status */}
              {isRunning && (
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4 flex gap-3">
                  <Loader2 className="w-5 h-5 text-blue-400 animate-spin flex-shrink-0" />
                  <div>
                    <h3 className="font-bold text-blue-300">Processing...</h3>
                    <p className="text-blue-200/80 text-sm">
                      Generating unique descriptions for all equipment items. This may take a few minutes.
                    </p>
                  </div>
                </div>
              )}

              {/* Results */}
              {result && (
                <div className={`rounded-lg p-4 border ${result.success ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                  <div className="flex gap-3">
                    <CheckCircle className={`w-5 h-5 ${result.success ? 'text-green-400' : 'text-red-400'} flex-shrink-0 mt-0.5`} />
                    <div>
                      <h3 className={`font-bold ${result.success ? 'text-green-300' : 'text-red-300'} mb-1`}>
                        {result.success ? 'Success!' : 'Error'}
                      </h3>
                      <p className={`${result.success ? 'text-green-200/80' : 'text-red-200/80'} text-sm mb-3`}>
                        {result.message}
                      </p>
                      {result.updated !== undefined && (
                        <div className="text-sm space-y-1">
                          <p className="text-cream/70">
                            <span className="font-semibold text-green-300">{result.updated}</span> items updated
                          </p>
                          {result.failed > 0 && (
                            <p className="text-cream/70">
                              <span className="font-semibold text-yellow-300">{result.failed}</span> items failed
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Sample Results */}
              {result?.results && result.results.length > 0 && (
                <div className="bg-navy-deep rounded-lg p-4 border border-orange/20">
                  <h3 className="font-bold text-orange mb-4">Sample Updated Descriptions:</h3>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {result.results.slice(0, 5).map((item: any) => (
                      <div key={item.id} className="pb-4 border-b border-cream/10 last:border-b-0">
                        <p className="font-semibold text-cream mb-2">{item.name}</p>
                        <p className="text-cream/70 text-sm italic">"{item.description}"</p>
                      </div>
                    ))}
                  </div>
                  {result.results.length > 5 && (
                    <p className="text-cream/50 text-xs mt-3">
                      ... and {result.results.length - 5} more items
                    </p>
                  )}
                </div>
              )}

              {/* Action Button */}
              <Button
                onClick={handleRegenerate}
                disabled={isRunning}
                className="w-full bg-orange hover:bg-orange-dark text-white font-[Oswald] uppercase tracking-wider h-12 text-lg gap-2"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Regenerate All Descriptions'
                )}
              </Button>
            </div>
          </Card>

          {/* Info */}
          <Card className="bg-navy-light border-orange/20 p-6">
            <h3 className="font-bold text-orange mb-3">How it works:</h3>
            <ul className="space-y-2 text-cream/70 text-sm">
              <li>✓ Analyzes each equipment type and category</li>
              <li>✓ Generates unique descriptions with mixed tone</li>
              <li>✓ Technical focus for B2B equipment (scaffolding, hydraulics, etc.)</li>
              <li>✓ Casual/friendly tone for DIY equipment (power tools, etc.)</li>
              <li>✓ Includes practical benefits and use cases</li>
              <li>✓ Avoids generic/repetitive phrases</li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
