/**
 * GitHub Backup Job
 * Exports the EquipHK codebase and database dump, then pushes them
 * to the private GitHub backup repository automatically.
 */
import { execSync } from "child_process";
import { createWriteStream, mkdirSync, writeFileSync, rmSync, existsSync } from "fs";
import path from "path";
import archiver from "archiver";
import { getDb } from "./db";
import { ENV } from "./_core/env";

const BACKUP_REPO_DIR = "/home/ubuntu/equiphk-backup-repo";
const PROJECT_DIR = "/home/ubuntu/equiphk";
const GITHUB_REMOTE = "github-equiphk-backup:EquipHK/Equip-HK---backup-.git"; // EquipHK-Server-Backup repo

// Directories/files to exclude from the code ZIP
const EXCLUDE_PATTERNS = [
  "node_modules",
  ".git",
  "dist",
  ".manus-logs",
  "drizzle/migrations",
];

async function createCodeZip(outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const output = createWriteStream(outputPath);
    const archive = archiver("zip", { zlib: { level: 6 } });

    output.on("close", resolve);
    archive.on("error", reject);
    archive.pipe(output);

    archive.glob("**/*", {
      cwd: PROJECT_DIR,
      ignore: EXCLUDE_PATTERNS.map((p) => `${p}/**`).concat(EXCLUDE_PATTERNS),
      dot: true,
    });

    archive.finalize();
  });
}

async function createDbDump(outputPath: string): Promise<void> {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) throw new Error("DATABASE_URL not set");

  // Parse the connection URL
  const url = new URL(dbUrl);
  const host = url.hostname;
  const port = url.port || "4000";
  const user = url.username;
  const password = url.password;
  const database = url.pathname.replace("/", "");

  const mysqldump = "/opt/homebrew/opt/mysql-client/bin/mysqldump";
  const fallbackDump = "mysqldump";

  // Try to find mysqldump — use the server's mysqldump if available
  let dumpCmd: string;
  try {
    execSync(`which ${fallbackDump}`, { stdio: "ignore" });
    dumpCmd = fallbackDump;
  } catch {
    // mysqldump not available on server — create a schema-only dump using drizzle
    dumpCmd = "";
  }

  if (dumpCmd) {
    const cmd = `${dumpCmd} --host="${host}" --port="${port}" --user="${user}" --password="${password}" --ssl-mode=REQUIRED --no-tablespaces "${database}" > "${outputPath}"`;
    execSync(cmd, { stdio: "pipe", timeout: 120000 });
  } else {
    // Fallback: export table list and row counts as a summary
    const db = await getDb();
    if (!db) throw new Error("Could not connect to database");
    const tables = await db.execute("SHOW TABLES");
    const summary = {
      exported_at: new Date().toISOString(),
      note: "Full mysqldump not available on server. Use Management UI → Database to export full data.",
      tables: (tables as unknown as Array<Record<string, string>>).map((r) => Object.values(r)[0]),
    };
    writeFileSync(outputPath, JSON.stringify(summary, null, 2));
  }
}

export async function runGitHubBackup(): Promise<{
  success: boolean;
  commitSha?: string;
  error?: string;
}> {
  const dateStr = new Date().toISOString().split("T")[0];
  const tmpDir = `/tmp/equiphk-backup-${Date.now()}`;

  try {
    console.log(`[GitHubBackup] Starting backup for ${dateStr}...`);
    mkdirSync(tmpDir, { recursive: true });

    // 1. Create code ZIP
    console.log("[GitHubBackup] Creating code ZIP...");
    const zipPath = path.join(tmpDir, `equiphk_code_${dateStr}.zip`);
    await createCodeZip(zipPath);
    console.log(`[GitHubBackup] Code ZIP created`);

    // 2. Create DB dump
    console.log("[GitHubBackup] Creating database dump...");
    const dbPath = path.join(tmpDir, `equiphk_database_${dateStr}.sql`);
    try {
      await createDbDump(dbPath);
      console.log(`[GitHubBackup] Database dump created`);
    } catch (dbErr) {
      console.warn("[GitHubBackup] DB dump failed, continuing without it:", dbErr);
      writeFileSync(
        dbPath,
        `-- DB export failed at ${new Date().toISOString()}\n-- Use Management UI → Database to export manually.\n`
      );
    }

    // 3. Set up backup repo directory
    if (!existsSync(BACKUP_REPO_DIR)) {
      mkdirSync(BACKUP_REPO_DIR, { recursive: true });
      execSync(`git init && git config user.email "backup@equiphk.server" && git config user.name "EquipHK Backup" && git remote add origin ${GITHUB_REMOTE}`, {
        cwd: BACKUP_REPO_DIR,
        stdio: "pipe",
      });
    }

    // 4. Copy files into the backup repo
    const backupDir = path.join(BACKUP_REPO_DIR, "backups", dateStr);
    mkdirSync(backupDir, { recursive: true });
    execSync(`cp "${zipPath}" "${backupDir}/"`, { stdio: "pipe" });
    execSync(`cp "${dbPath}" "${backupDir}/"`, { stdio: "pipe" });

    // Write a README
    writeFileSync(
      path.join(BACKUP_REPO_DIR, "README.md"),
      `# EquipHK Backup Repository\n\nAutomated monthly backups of the EquipHK website.\n\nEach folder under \`backups/\` contains:\n- \`equiphk_code_YYYY-MM-DD.zip\` — full source code\n- \`equiphk_database_YYYY-MM-DD.sql\` — database export\n\nLast backup: ${dateStr}\n`
    );

    // 5. Commit and push
    console.log("[GitHubBackup] Committing and pushing to GitHub...");

    // Try to pull first (in case repo already has commits)
    try {
      execSync(`GIT_SSH_COMMAND="ssh -i /home/ubuntu/.ssh/equiphk-deploy-key -o StrictHostKeyChecking=no" git pull origin main --rebase 2>/dev/null || true`, {
        cwd: BACKUP_REPO_DIR,
        stdio: "pipe",
      });
    } catch {
      // ignore pull errors on first push
    }

    execSync(`git add -A`, { cwd: BACKUP_REPO_DIR, stdio: "pipe" });

    // Check if there's anything to commit
    const status = execSync(`git status --porcelain`, { cwd: BACKUP_REPO_DIR }).toString().trim();
    if (!status) {
      console.log("[GitHubBackup] Nothing to commit — backup already up to date");
      return { success: true, commitSha: "no-changes" };
    }

    execSync(`git commit -m "Monthly backup ${dateStr}"`, {
      cwd: BACKUP_REPO_DIR,
      stdio: "pipe",
    });

    execSync(
      `GIT_SSH_COMMAND="ssh -i /home/ubuntu/.ssh/equiphk-deploy-key -o StrictHostKeyChecking=no" git push origin HEAD:main`,
      { cwd: BACKUP_REPO_DIR, stdio: "pipe" }
    );

    const commitSha = execSync(`git rev-parse --short HEAD`, { cwd: BACKUP_REPO_DIR })
      .toString()
      .trim();

    console.log(`[GitHubBackup] Pushed successfully — commit ${commitSha}`);

    // Cleanup tmp
    rmSync(tmpDir, { recursive: true, force: true });

    return { success: true, commitSha };
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    console.error("[GitHubBackup] Failed:", error);
    try { rmSync(tmpDir, { recursive: true, force: true }); } catch {}
    return { success: false, error };
  }
}
